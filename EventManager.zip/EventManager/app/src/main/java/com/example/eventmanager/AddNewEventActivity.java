package com.example.eventmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eventmanager.Database.myDbAdapter;

public class AddNewEventActivity extends AppCompatActivity {

    
    Button addNewEvent;

    myDbAdapter dbAdapter;
    TextView eventName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_event);
    
    addNewEvent=(Button) findViewById(R.id.AddNewEvent);
        dbAdapter= new myDbAdapter(this);

        eventName=(TextView) findViewById(R.id.editTextEventName);
    addNewEvent.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            dbAdapter.insertData(eventName.getText().toString(),"22/02/2021");
            Intent intent = new Intent(AddNewEventActivity.this, MainPageActivity.class);
            startActivity(intent);
        }
    });
    }
}