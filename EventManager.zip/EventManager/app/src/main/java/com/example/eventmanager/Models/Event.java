package com.example.eventmanager.Models;

public class Event {

    public String date;
    public String title;
    Event(){
        this.date = "";
        this.title="";
    }
    Event( String title, String date){
        this.title=title;
        this.date=date;
    }

}
