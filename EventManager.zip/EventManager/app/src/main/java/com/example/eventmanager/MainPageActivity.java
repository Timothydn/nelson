package com.example.eventmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.eventmanager.Database.myDbAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainPageActivity extends AppCompatActivity {

    FloatingActionButton addNewEvent;

    myDbAdapter dbAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        
        addNewEvent=(FloatingActionButton) findViewById(R.id.floatingActionButton);

        String[] mobileArray = {"Android","IPhone","WindowsMobile","Blackberry",
                "WebOS","Ubuntu","Windows7","Max OS X"};
        dbAdapter= new myDbAdapter(this);
        ArrayAdapter adapter = new ArrayAdapter<String>(this,R.layout.listviewevents,dbAdapter.getData());



        Log.e("testing", "calling get data methodl");
        dbAdapter.getData();
        ListView listView;
        listView = (ListView) findViewById(R.id.listViewEvent);
        listView.setAdapter(adapter);


        addNewEvent.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainPageActivity.this, AddNewEventActivity.class);
                    startActivity(intent);
            }
            }
            );
    }
}